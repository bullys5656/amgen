import { useState } from 'react';
import { Button, Select } from '../../components/common';
import { getWeekNumber } from '../../utils';
import './Analisis.css';

// Opciones mock para los selects (después se cargarán desde la API)
const ESTADO_WFC_OPTIONS = [
  { value: 'pendiente', label: 'Pendiente' },
  { value: 'procesado', label: 'Procesado' },
  { value: 'cancelado', label: 'Cancelado' },
];

const ESTADO_PENDIENTES_OPTIONS = [
  { value: 'todos', label: 'Todos' },
  { value: 'con_pendientes', label: 'Con Pendientes' },
  { value: 'sin_pendientes', label: 'Sin Pendientes' },
];

const DROGUERIA_OPTIONS = [
  { value: 'drogueria1', label: 'Droguería 1' },
  { value: 'drogueria2', label: 'Droguería 2' },
  { value: 'drogueria3', label: 'Droguería 3' },
];

const CONVENIO_OPTIONS = [
  { value: 'convenio1', label: 'Convenio 1' },
  { value: 'convenio2', label: 'Convenio 2' },
  { value: 'convenio3', label: 'Convenio 3' },
];

const PRODUCTO_OPTIONS = [
  { value: 'producto1', label: 'Producto 1' },
  { value: 'producto2', label: 'Producto 2' },
  { value: 'producto3', label: 'Producto 3' },
];

const Analisis = () => {
  // Estado de los filtros
  const [filters, setFilters] = useState({
    estadoWFC: '',
    estadoPendientes: '',
    drogueria: '',
    convenio: '',
    producto: '',
    fechaDesde: '',
    fechaHasta: '',
  });

  const [loading, setLoading] = useState(false);
  
  // Semana actual calculada automáticamente
  const semanaActual = getWeekNumber();

  // Actualizar un filtro específico
  const handleFilterChange = (field, value) => {
    setFilters(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  // Limpiar todos los filtros
  const handleClearFilters = () => {
    setFilters({
      estadoWFC: '',
      estadoPendientes: '',
      drogueria: '',
      convenio: '',
      producto: '',
      fechaDesde: '',
      fechaHasta: '',
    });
  };

  // Buscar con los filtros
  const handleBuscar = () => {
    setLoading(true);
    console.log('Buscando con filtros:', filters);
    // Aquí irá la llamada a la API
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  // Analizar
  const handleAnalizar = () => {
    console.log('Analizando...');
    // Implementar lógica de análisis
  };

  // Generar orden
  const handleGenerarOrden = () => {
    console.log('Generando orden...');
    // Implementar lógica de generación de orden
  };

  return (
    <div className="analisis-page">
      {/* Header con título y botones de acción */}
      <div className="analisis-page__header">
        <h1 className="analisis-page__title">Semana {semanaActual}</h1>
        <div className="analisis-page__actions">
          <Button variant="primary" onClick={handleAnalizar}>
            ANALIZAR
          </Button>
          <Button variant="outline" onClick={handleGenerarOrden}>
            GENERAR ORDEN
          </Button>
        </div>
      </div>

      {/* Filtros */}
      <div className="analisis-page__filters">
        <Select
          label="Estado WFC"
          value={filters.estadoWFC}
          onChange={(value) => handleFilterChange('estadoWFC', value)}
          options={ESTADO_WFC_OPTIONS}
          placeholder="Text Input"
        />

        <Select
          label="Estado Pendientes"
          value={filters.estadoPendientes}
          onChange={(value) => handleFilterChange('estadoPendientes', value)}
          options={ESTADO_PENDIENTES_OPTIONS}
          placeholder="Text Input"
        />

        <Select
          label="Droguería"
          value={filters.drogueria}
          onChange={(value) => handleFilterChange('drogueria', value)}
          options={DROGUERIA_OPTIONS}
          placeholder="Text Input"
        />

        <Select
          label="Convenio"
          value={filters.convenio}
          onChange={(value) => handleFilterChange('convenio', value)}
          options={CONVENIO_OPTIONS}
          placeholder="Text Input"
        />

        <Select
          label="Producto"
          value={filters.producto}
          onChange={(value) => handleFilterChange('producto', value)}
          options={PRODUCTO_OPTIONS}
          placeholder="Text Input"
        />

        <div className="analisis-page__date-field">
          <label className="analisis-page__label">Fecha Desde</label>
          <div className="analisis-page__date-input">
            <CalendarIcon />
            <input
              type="date"
              value={filters.fechaDesde}
              onChange={(e) => handleFilterChange('fechaDesde', e.target.value)}
              placeholder="00/00/0000"
            />
          </div>
        </div>

        <div className="analisis-page__date-field">
          <label className="analisis-page__label">Fecha Hasta</label>
          <div className="analisis-page__date-input">
            <CalendarIcon />
            <input
              type="date"
              value={filters.fechaHasta}
              onChange={(e) => handleFilterChange('fechaHasta', e.target.value)}
              placeholder="00/00/0000"
            />
          </div>
        </div>

        <div className="analisis-page__filter-actions">
          <Button variant="primary" onClick={handleBuscar} disabled={loading}>
            {loading ? 'BUSCANDO...' : 'BUSCAR'}
          </Button>
          <Button variant="outline" onClick={handleClearFilters}>
            <ClearIcon />
          </Button>
        </div>
      </div>

      {/* Área de contenido (tabla de resultados) */}
      <div className="analisis-page__content">
        {/* Aquí irá la tabla de resultados cuando se implemente */}
        <div className="analisis-page__empty">
          <p>Seleccione los filtros y presione BUSCAR para ver los resultados.</p>
        </div>
      </div>
    </div>
  );
};

// Íconos
const CalendarIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
    <line x1="16" y1="2" x2="16" y2="6" />
    <line x1="8" y1="2" x2="8" y2="6" />
    <line x1="3" y1="10" x2="21" y2="10" />
  </svg>
);

const ClearIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
  </svg>
);

export default Analisis;
