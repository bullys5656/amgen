export { default as Analisis } from './Analisis';
