import { useState, useEffect } from 'react';
import api from '../../services/api';
import './AuditoriaStock.css';

/**
 * Verifica si una fecha está dentro de la semana en curso.
 * La semana va de lunes a domingo.
 */
const isCurrentWeek = (dateString) => {
  if (!dateString) return false;

  const date = new Date(dateString);
  if (isNaN(date)) return false;

  const now = new Date();

  // Lunes de la semana actual
  const dayOfWeek = now.getDay(); // 0=Dom, 1=Lun, ...
  const diffToMonday = (dayOfWeek === 0 ? -6 : 1 - dayOfWeek);
  const monday = new Date(now);
  monday.setDate(now.getDate() + diffToMonday);
  monday.setHours(0, 0, 0, 0);

  // Domingo de la semana actual
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  sunday.setHours(23, 59, 59, 999);

  return date >= monday && date <= sunday;
};

const formatFecha = (dateString) => {
  if (!dateString) return '00/00/0000';
  const date = new Date(dateString);
  if (isNaN(date)) return '00/00/0000';
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const yyyy = date.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
};

const CheckIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#28A745" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

const CrossIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#DC3545" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

const AuditoriaStock = () => {
  const [droguerias, setDroguerias] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchDroguerias = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await api.get('/droguerias');
        setDroguerias(response.data);
      } catch (err) {
        console.error('Error fetching droguerias:', err);
        setError('No se pudieron cargar las droguerías. Verifique la conexión con el servidor.');
      } finally {
        setLoading(false);
      }
    };

    fetchDroguerias();
  }, []);

  return (
    <div className="auditoria-page">
      <div className="auditoria-table__wrapper">
        {loading && (
          <div className="auditoria-loading">
            <div className="auditoria-loading__spinner"></div>
            <span>Cargando droguerías...</span>
          </div>
        )}

        {error && (
          <div className="auditoria-error">
            {error}
          </div>
        )}

        {!loading && !error && (
          <table className="auditoria-table">
            <thead>
              <tr>
                <th className="auditoria-table__header auditoria-table__header--name">Droguería</th>
                <th className="auditoria-table__header auditoria-table__header--date">Fecha Ultima Carga</th>
                <th className="auditoria-table__header auditoria-table__header--status"></th>
              </tr>
            </thead>
            <tbody>
              {droguerias.length === 0 ? (
                <tr>
                  <td colSpan="3" className="auditoria-table__empty">
                    No hay droguerías registradas.
                  </td>
                </tr>
              ) : (
                droguerias.map((drogueria) => {
                  const ok = isCurrentWeek(drogueria.fechaUltimaCarga);
                  return (
                    <tr key={drogueria.drogueriaId} className="auditoria-table__row">
                      <td className="auditoria-table__cell auditoria-table__cell--name">
                        {drogueria.nombre}
                      </td>
                      <td className="auditoria-table__cell auditoria-table__cell--date">
                        {formatFecha(drogueria.fechaUltimaCarga)}
                      </td>
                      <td className="auditoria-table__cell auditoria-table__cell--status">
                        {ok ? <CheckIcon /> : <CrossIcon />}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default AuditoriaStock;