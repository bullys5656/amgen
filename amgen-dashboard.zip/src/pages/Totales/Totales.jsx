import { useState } from 'react';
import { Button } from '../../components/common';
import './Totales.css';

// Datos mock basados en la imagen - estructura por columnas (períodos)
const MOCK_PERIODS = [
  { mes: 'Ago - 25', semana: 35, reposicionTotal: 0, actualTotal: 515, pendientesTotal: 323 },
  { mes: 'Ago - 25', semana: 36, reposicionTotal: 0, actualTotal: 515, pendientesTotal: 323 },
  { mes: 'Sep - 25', semana: 37, reposicionTotal: 615, actualTotal: 515, pendientesTotal: 323 },
  { mes: 'Sep - 25', semana: 38, reposicionTotal: 419, actualTotal: 453, pendientesTotal: 323 },
  { mes: 'Sep - 25', semana: 39, reposicionTotal: 297, actualTotal: 393, pendientesTotal: 323 },
  { mes: 'Sep - 25', semana: 40, reposicionTotal: 4, actualTotal: 676, pendientesTotal: 323 },
  { mes: 'Oct - 25', semana: 41, reposicionTotal: 1225, actualTotal: 526, pendientesTotal: 323 },
  { mes: 'Oct - 25', semana: 42, reposicionTotal: 225, actualTotal: 538, pendientesTotal: 323 },
  { mes: 'Oct - 25', semana: 43, reposicionTotal: 10, actualTotal: 445, pendientesTotal: 323 },
  { mes: 'Oct - 25', semana: 44, reposicionTotal: 756, actualTotal: 378, pendientesTotal: 323 },
  { mes: 'Nov - 25', semana: 45, reposicionTotal: 884, actualTotal: 793, pendientesTotal: 323 },
  { mes: 'Nov - 25', semana: 46, reposicionTotal: 1130, actualTotal: null, pendientesTotal: 323 },
  { mes: 'Nov - 25', semana: 47, reposicionTotal: 4, actualTotal: null, pendientesTotal: 323 },
  { mes: 'Nov - 25', semana: 48, reposicionTotal: 2988, actualTotal: null, pendientesTotal: 323 },
  { mes: 'Dic - 25', semana: 49, reposicionTotal: 26, actualTotal: null, pendientesTotal: 323 },
];

// Definición de filas para la tabla transpuesta
const ROW_DEFINITIONS = [
  { key: 'mes', label: 'Mes' },
  { key: 'semana', label: 'Semana' },
  { key: 'reposicionTotal', label: 'Reposición Total' },
  { key: 'actualTotal', label: 'Actual Total' },
  { key: 'pendientesTotal', label: 'Pendientes Total' },
];

const Totales = () => {
  const [fechaDesde, setFechaDesde] = useState('');
  const [fechaHasta, setFechaHasta] = useState('');
  const [data, setData] = useState(MOCK_PERIODS);
  const [loading, setLoading] = useState(false);

  const handleBuscar = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleExportXLS = () => {
    console.log('Exportando a XLS...');
  };

  const handleExportPDF = () => {
    console.log('Exportando a PDF...');
  };

  const formatValue = (value) => {
    if (value === null || value === undefined) return '-';
    return value;
  };

  return (
    <div className="totales-page">
      {/* Filtros */}
      <div className="totales-page__filters">
        <div className="totales-page__date-filters">
          <div className="totales-page__date-field">
            <label className="totales-page__label">Fecha Desde</label>
            <div className="totales-page__date-input">
              <CalendarIcon />
              <input
                type="date"
                value={fechaDesde}
                onChange={(e) => setFechaDesde(e.target.value)}
                placeholder="00/00/0000"
              />
            </div>
          </div>

          <div className="totales-page__date-field">
            <label className="totales-page__label">Fecha Hasta</label>
            <div className="totales-page__date-input">
              <CalendarIcon />
              <input
                type="date"
                value={fechaHasta}
                onChange={(e) => setFechaHasta(e.target.value)}
                placeholder="00/00/0000"
              />
            </div>
          </div>

          <Button variant="primary" onClick={handleBuscar}>
            BUSCAR
          </Button>
        </div>

        <div className="totales-page__export-buttons">
          <Button variant="outline" onClick={() => {}}>
            <CopyIcon />
          </Button>
          <Button variant="outline" onClick={handleExportXLS}>
            <ExcelIcon />
            XLS
          </Button>
          <Button variant="outline" onClick={handleExportPDF}>
            <PdfIcon />
            PDF
          </Button>
        </div>
      </div>

      {/* Tabla Transpuesta - ocupa todo el ancho */}
      <div className="totales-table__wrapper">
        <table className="totales-table">
          <tbody>
            {ROW_DEFINITIONS.map((row) => (
              <tr key={row.key} className="totales-table__row">
                <td className="totales-table__label-cell">{row.label}</td>
                {data.map((period, index) => (
                  <td 
                    key={index} 
                    className={`totales-table__data-cell ${row.key === 'semana' && index === data.length - 1 ? 'totales-table__data-cell--highlight' : ''}`}
                  >
                    {formatValue(period[row.key])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// Íconos
const CalendarIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
    <line x1="16" y1="2" x2="16" y2="6" />
    <line x1="8" y1="2" x2="8" y2="6" />
    <line x1="3" y1="10" x2="21" y2="10" />
  </svg>
);

const CopyIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
  </svg>
);

const ExcelIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <polyline points="14,2 14,8 20,8" />
    <line x1="8" y1="13" x2="16" y2="13" />
    <line x1="8" y1="17" x2="16" y2="17" />
  </svg>
);

const PdfIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <polyline points="14,2 14,8 20,8" />
  </svg>
);

export default Totales;
