export { default as Totales } from './Totales';
