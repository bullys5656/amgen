import api from './api';

export const authService = {
  /**
   * Iniciar sesión con email y contraseña
   * @param {string} email - Email del usuario
   * @param {string} password - Contraseña del usuario
   * @returns {Promise<{success: boolean, message: string, token: string|null, userId: number|null}>}
   */
  login: async (email, password) => {
    try {
      const response = await api.post('/auth/login', { email, password });
      const data = response.data;
      
      if (data.success && data.token) {
        // Guardar token y userId en localStorage
        localStorage.setItem('token', data.token);
        localStorage.setItem('userId', data.userId);
      }
      
      return data;
    } catch (error) {
      // Manejar errores de red o del servidor
      if (error.response) {
        // El servidor respondió con un código de error
        return {
          success: false,
          message: error.response.data?.message || 'Error de autenticación',
          token: null,
          userId: null
        };
      } else if (error.request) {
        // La petición se hizo pero no hubo respuesta
        return {
          success: false,
          message: 'No se pudo conectar con el servidor',
          token: null,
          userId: null
        };
      } else {
        // Error al configurar la petición
        return {
          success: false,
          message: 'Error al procesar la solicitud',
          token: null,
          userId: null
        };
      }
    }
  },

  /**
   * Cerrar sesión
   */
  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
  },

  /**
   * Verificar si el usuario está autenticado
   * @returns {boolean}
   */
  isAuthenticated: () => {
    return !!localStorage.getItem('token');
  },

  /**
   * Obtener el token actual
   * @returns {string|null}
   */
  getToken: () => {
    return localStorage.getItem('token');
  },

  /**
   * Obtener el ID del usuario actual
   * @returns {string|null}
   */
  getUserId: () => {
    return localStorage.getItem('userId');
  }
};

export default authService;
