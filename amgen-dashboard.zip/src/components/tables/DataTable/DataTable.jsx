import './DataTable.css';

/**
 * Componente DataTable genérico y reutilizable
 * 
 * @param {Object} props
 * @param {Array} props.columns - Configuración de columnas [{key, label, sticky?, width?, align?}]
 * @param {Array} props.data - Datos de la tabla
 * @param {boolean} props.loading - Estado de carga
 * @param {string} props.emptyMessage - Mensaje cuando no hay datos
 * @param {function} props.onRowClick - Callback al hacer click en una fila
 * @param {string} props.className - Clases adicionales
 */
const DataTable = ({
  columns = [],
  data = [],
  loading = false,
  emptyMessage = 'No hay datos disponibles',
  onRowClick,
  className = '',
}) => {
  const renderCell = (row, column) => {
    const value = row[column.key];
    
    // Si hay un render personalizado
    if (column.render) {
      return column.render(value, row);
    }
    
    // Valor por defecto
    return value ?? '-';
  };

  if (loading) {
    return (
      <div className="data-table__loading">
        <div className="data-table__spinner" />
        <span>Cargando...</span>
      </div>
    );
  }

  return (
    <div className={`data-table__wrapper ${className}`}>
      <table className="data-table">
        <thead className="data-table__head">
          <tr>
            {columns.map((column) => (
              <th
                key={column.key}
                className={`data-table__th ${column.sticky ? 'data-table__th--sticky' : ''}`}
                style={{
                  width: column.width,
                  textAlign: column.align || 'left',
                }}
              >
                {column.label}
              </th>
            ))}
          </tr>
        </thead>
        
        <tbody className="data-table__body">
          {data.length === 0 ? (
            <tr>
              <td 
                colSpan={columns.length} 
                className="data-table__empty"
              >
                {emptyMessage}
              </td>
            </tr>
          ) : (
            data.map((row, rowIndex) => (
              <tr
                key={row.id || rowIndex}
                className={`data-table__row ${onRowClick ? 'data-table__row--clickable' : ''}`}
                onClick={() => onRowClick?.(row)}
              >
                {columns.map((column) => (
                  <td
                    key={column.key}
                    className={`data-table__td ${column.sticky ? 'data-table__td--sticky' : ''}`}
                    style={{ textAlign: column.align || 'left' }}
                  >
                    {renderCell(row, column)}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;
