import { NAV_ITEMS } from '../../../constants';
import './Navbar.css';

/**
 * Componente Navbar principal
 * 
 * @param {Object} props
 * @param {string} props.username - Nombre del usuario
 * @param {string} props.activePath - Ruta activa actual
 * @param {function} props.onNavigate - Callback de navegación
 * @param {function} props.onLogout - Callback de logout
 */
const Navbar = ({ 
  username = 'Username', 
  activePath = '/totales',
  onNavigate,
  onLogout 
}) => {
  const handleNavClick = (path) => {
    if (onNavigate) {
      onNavigate(path);
    }
  };

  const handleLogout = () => {
    if (onLogout) {
      onLogout();
    }
  };

  return (
    <nav className="navbar">
      <div className="navbar__container">
        {/* Logo */}
        <div className="navbar__logo">
          <img 
            src="/amgen-logo.svg" 
            alt="Amgen" 
            className="navbar__logo-img"
          />
        </div>

        {/* Navegación */}
        <ul className="navbar__nav">
          {NAV_ITEMS.map((item) => (
            <li key={item.path} className="navbar__nav-item">
              <button
                className={`navbar__nav-link ${
                  activePath === item.path ? 'navbar__nav-link--active' : ''
                }`}
                onClick={() => handleNavClick(item.path)}
              >
                {item.label}
              </button>
            </li>
          ))}
        </ul>

        {/* Usuario y acciones */}
        <div className="navbar__actions">
          <span className="navbar__username">{username}</span>
          
          <button className="navbar__icon-btn" aria-label="Usuario">
            <UserIcon />
          </button>
          
          <button className="navbar__icon-btn" aria-label="Mensajes">
            <MessageIcon />
          </button>
          
          <button 
            className="navbar__icon-btn" 
            aria-label="Cerrar sesión"
            onClick={handleLogout}
          >
            <LogoutIcon />
          </button>
        </div>
      </div>
    </nav>
  );
};

// Íconos simples (puedes reemplazar con lucide-react después)
const UserIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </svg>
);

const MessageIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
  </svg>
);

const LogoutIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
    <polyline points="16,17 21,12 16,7" />
    <line x1="21" y1="12" x2="9" y2="12" />
  </svg>
);

export default Navbar;
