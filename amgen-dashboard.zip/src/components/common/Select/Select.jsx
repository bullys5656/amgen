import './Select.css';

/**
 * Componente Select reutilizable
 * 
 * @param {Object} props
 * @param {string} props.label - Etiqueta del campo
 * @param {string} props.value - Valor seleccionado
 * @param {function} props.onChange - Callback cuando cambia el valor
 * @param {Array} props.options - Opciones [{value, label}]
 * @param {string} props.placeholder - Texto placeholder
 * @param {boolean} props.disabled - Estado deshabilitado
 * @param {string} props.className - Clases adicionales
 */
const Select = ({
  label,
  value = '',
  onChange,
  options = [],
  placeholder = 'Seleccionar',
  disabled = false,
  className = '',
  ...props
}) => {
  return (
    <div className={`select-field ${className}`}>
      {label && <label className="select-field__label">{label}</label>}
      <div className="select-field__wrapper">
        <select
          className="select-field__input"
          value={value}
          onChange={(e) => onChange?.(e.target.value)}
          disabled={disabled}
          {...props}
        >
          <option value="">{placeholder}</option>
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <ChevronDownIcon className="select-field__icon" />
      </div>
    </div>
  );
};

const ChevronDownIcon = ({ className }) => (
  <svg 
    className={className}
    width="16" 
    height="16" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2"
  >
    <polyline points="6,9 12,15 18,9" />
  </svg>
);

export default Select;
