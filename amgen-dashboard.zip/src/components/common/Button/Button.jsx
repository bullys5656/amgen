import './Button.css';

/**
 * Componente Button reutilizable
 * 
 * @param {Object} props
 * @param {'primary' | 'secondary' | 'outline' | 'ghost'} props.variant - Variante visual
 * @param {'sm' | 'md' | 'lg'} props.size - Tamaño del botón
 * @param {boolean} props.fullWidth - Si ocupa todo el ancho
 * @param {boolean} props.disabled - Estado deshabilitado
 * @param {React.ReactNode} props.leftIcon - Ícono izquierdo
 * @param {React.ReactNode} props.rightIcon - Ícono derecho
 * @param {React.ReactNode} props.children - Contenido del botón
 */
const Button = ({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  leftIcon,
  rightIcon,
  children,
  className = '',
  ...props
}) => {
  const classNames = [
    'btn',
    `btn--${variant}`,
    `btn--${size}`,
    fullWidth && 'btn--full-width',
    className,
  ].filter(Boolean).join(' ');

  return (
    <button
      className={classNames}
      disabled={disabled}
      {...props}
    >
      {leftIcon && <span className="btn__icon btn__icon--left">{leftIcon}</span>}
      {children && <span className="btn__text">{children}</span>}
      {rightIcon && <span className="btn__icon btn__icon--right">{rightIcon}</span>}
    </button>
  );
};

export default Button;
