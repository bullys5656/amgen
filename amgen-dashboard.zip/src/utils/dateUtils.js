/**
 * Utilidades para manejo de fechas
 */

/**
 * Obtiene el número de semana del año para una fecha dada
 * Usa el estándar ISO 8601 (la semana comienza el lunes)
 * 
 * @param {Date} date - Fecha a evaluar (por defecto, fecha actual)
 * @returns {number} - Número de semana (1-52/53)
 */
export const getWeekNumber = (date = new Date()) => {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  
  // Ajustar al jueves más cercano (ISO 8601)
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  
  // Obtener el primer día del año
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  
  // Calcular el número de semana
  const weekNumber = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  
  return weekNumber;
};

/**
 * Obtiene información completa de la semana actual
 * 
 * @returns {Object} - { weekNumber, year, startDate, endDate }
 */
export const getCurrentWeekInfo = () => {
  const now = new Date();
  const weekNumber = getWeekNumber(now);
  const year = now.getFullYear();
  
  // Calcular fecha de inicio de la semana (lunes)
  const startDate = new Date(now);
  const day = startDate.getDay();
  const diff = startDate.getDate() - day + (day === 0 ? -6 : 1);
  startDate.setDate(diff);
  startDate.setHours(0, 0, 0, 0);
  
  // Calcular fecha de fin de la semana (domingo)
  const endDate = new Date(startDate);
  endDate.setDate(startDate.getDate() + 6);
  endDate.setHours(23, 59, 59, 999);
  
  return {
    weekNumber,
    year,
    startDate,
    endDate,
  };
};

/**
 * Formatea una fecha a string legible
 * 
 * @param {Date} date - Fecha a formatear
 * @param {string} format - Formato ('short', 'long', 'iso')
 * @returns {string}
 */
export const formatDate = (date, format = 'short') => {
  if (!date) return '';
  
  const d = new Date(date);
  
  switch (format) {
    case 'iso':
      return d.toISOString().split('T')[0]; // YYYY-MM-DD
    case 'long':
      return d.toLocaleDateString('es-AR', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    case 'short':
    default:
      return d.toLocaleDateString('es-AR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      });
  }
};
