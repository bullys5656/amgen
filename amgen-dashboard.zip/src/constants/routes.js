/**
 * Rutas de la aplicación
 */
export const ROUTES = {
  HOME: '/',
  ANALISIS: '/analisis',
  TOTALES: '/totales',
  AUDITORIA_STOCK: '/auditoria-stock',
  STOCK: '/stock',
};

/**
 * Configuración de navegación
 */
export const NAV_ITEMS = [
  { label: 'Análisis', path: ROUTES.ANALISIS },
  { label: 'Totales', path: ROUTES.TOTALES },
  { label: 'Auditoría de Stock', path: ROUTES.AUDITORIA_STOCK },
  { label: 'Stock', path: ROUTES.STOCK },
];
