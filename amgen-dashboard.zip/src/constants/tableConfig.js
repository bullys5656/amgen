/**
 * Configuración de columnas para la tabla de Totales
 */
export const TOTALES_COLUMNS = [
  { key: 'mes', label: 'Mes', sticky: true },
  { key: 'semana', label: 'Semana' },
  { key: 'reposicionTotal', label: 'Reposición Total' },
  { key: 'actualTotal', label: 'Actual Total' },
  { key: 'pendientesTotal', label: 'Pendientes Total' },
];

/**
 * Configuración general de tablas
 */
export const TABLE_CONFIG = {
  defaultPageSize: 20,
  pageSizeOptions: [10, 20, 50, 100],
};
