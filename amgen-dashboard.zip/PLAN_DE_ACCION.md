# Plan de Acción - Dashboard Amgen

## 📁 Estructura del Proyecto

```
src/
├── assets/
│   ├── images/          # Logos, imágenes estáticas
│   └── icons/           # Íconos SVG
│
├── components/
│   ├── common/          # Componentes genéricos reutilizables
│   │   ├── Button/
│   │   ├── Input/
│   │   └── index.js
│   │
│   ├── layout/          # Componentes de estructura
│   │   ├── Navbar/
│   │   ├── Sidebar/
│   │   ├── PageLayout/
│   │   └── index.js
│   │
│   ├── ui/              # Componentes de UI específicos
│   │   ├── DatePicker/
│   │   ├── ExportButtons/
│   │   └── index.js
│   │
│   ├── tables/          # Componentes de tablas
│   │   ├── DataTable/
│   │   ├── TableHeader/
│   │   └── index.js
│   │
│   └── filters/         # Componentes de filtrado
│       ├── DateRangeFilter/
│       └── index.js
│
├── pages/               # Páginas/Vistas completas
│   ├── Totales/
│   ├── Analisis/
│   ├── AuditoriaStock/
│   ├── Stock/
│   └── index.js
│
├── hooks/               # Custom hooks
│   ├── useFilters.js
│   ├── useTableData.js
│   └── index.js
│
├── services/            # Llamadas API
│   ├── api.js
│   ├── stockService.js
│   └── index.js
│
├── utils/               # Funciones utilitarias
│   ├── formatters.js
│   ├── validators.js
│   └── index.js
│
├── constants/           # Constantes y configuración
│   ├── routes.js
│   ├── tableConfig.js
│   └── index.js
│
├── context/             # Context API (estado global)
│   ├── AuthContext.jsx
│   └── index.js
│
└── styles/              # Estilos globales
    ├── variables.css
    ├── globals.css
    └── index.css
```

---

## 🎯 Componentes Identificados de la Vista "Totales"

### 1. Layout Components
| Componente | Ubicación | Descripción |
|------------|-----------|-------------|
| `Navbar` | `components/layout/` | Header con logo, navegación y usuario |
| `PageLayout` | `components/layout/` | Wrapper para las páginas |

### 2. UI Components
| Componente | Ubicación | Descripción |
|------------|-----------|-------------|
| `DatePicker` | `components/ui/` | Input de fecha con ícono calendario |
| `Button` | `components/common/` | Botón reutilizable (BUSCAR) |
| `ExportButtons` | `components/ui/` | Grupo de botones XLS/PDF |
| `IconButton` | `components/common/` | Botón con ícono |

### 3. Table Components
| Componente | Ubicación | Descripción |
|------------|-----------|-------------|
| `DataTable` | `components/tables/` | Tabla principal de datos |
| `TableHeader` | `components/tables/` | Cabecera de tabla |
| `TableRow` | `components/tables/` | Fila de tabla |
| `TableCell` | `components/tables/` | Celda de tabla |

### 4. Filter Components
| Componente | Ubicación | Descripción |
|------------|-----------|-------------|
| `DateRangeFilter` | `components/filters/` | Filtro de rango de fechas |

---

## 📋 Fases de Desarrollo

### Fase 1: Setup Base ✅
- [x] Crear proyecto Vite
- [x] Estructura de carpetas
- [ ] Configurar ESLint/Prettier
- [ ] Instalar dependencias (react-router-dom, etc.)
- [ ] Configurar variables CSS

### Fase 2: Componentes Base
- [ ] Button
- [ ] Input
- [ ] DatePicker
- [ ] IconButton

### Fase 3: Layout
- [ ] Navbar
- [ ] PageLayout
- [ ] Configurar rutas

### Fase 4: Componentes de Tabla
- [ ] DataTable genérico
- [ ] Estilos de tabla

### Fase 5: Vista Totales
- [ ] Integrar componentes
- [ ] Filtros de fecha
- [ ] Botones de exportación
- [ ] Datos mock

### Fase 6: Otras Vistas
- [ ] Análisis
- [ ] Auditoría de Stock
- [ ] Stock

---

## 🛠 Dependencias Recomendadas

```bash
# Routing
npm install react-router-dom

# Íconos
npm install lucide-react

# Fechas (opcional)
npm install date-fns

# Exportación (opcional)
npm install xlsx file-saver
```

---

## 📐 Convenciones de Código

### Nombrado
- **Componentes**: PascalCase (`DataTable.jsx`)
- **Hooks**: camelCase con prefijo "use" (`useTableData.js`)
- **Utilidades**: camelCase (`formatters.js`)
- **Constantes**: UPPER_SNAKE_CASE (`API_BASE_URL`)

### Estructura de Componente
```jsx
// ComponentName/
//   ├── ComponentName.jsx
//   ├── ComponentName.css (o .module.css)
//   └── index.js
```

### Exports
Usar barrel exports (index.js) para facilitar imports:
```jsx
// Antes
import Button from '../components/common/Button/Button';

// Después
import { Button } from '../components/common';
```
