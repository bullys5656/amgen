import { useState } from 'react';
import { useAuth } from './context';
import { Navbar } from './components/layout';
import { Analisis, Login, Totales, AuditoriaStock } from './pages';
import './styles/globals.css';

function App() {
  const { isAuthenticated, loading, logout, user } = useAuth();
  const [activePath, setActivePath] = useState('/analisis');

  const handleNavigate = (path) => {
    setActivePath(path);
    // Aquí integrarás react-router-dom después
  };

  // Mostrar loading mientras se verifica la autenticación
  if (loading) {
    return (
      <div className="app-loading">
        <div className="app-loading-spinner"></div>
      </div>
    );
  }

  // Si no está autenticado, mostrar Login
  if (!isAuthenticated) {
    return <Login />;
  }

  // Renderizar página según la ruta activa
  const renderPage = () => {
    switch (activePath) {
      case '/analisis':
        return <Analisis />;
      case '/totales':
        return <Totales />;
      case '/auditoria-stock':
  return <AuditoriaStock />;
      case '/stock':
        return <PlaceholderPage title="Stock" />;
      default:
        return <Analisis />;
    }
  };

  return (
    <div className="app">
      <Navbar 
        username={user?.email || 'Usuario'} 
        activePath={activePath}
        onNavigate={handleNavigate}
        onLogout={logout}
      />
      <main className="app__main">
        {renderPage()}
      </main>
    </div>
  );
}

// Componente placeholder para páginas no implementadas
const PlaceholderPage = ({ title }) => (
  <div style={{ 
    padding: '2rem', 
    textAlign: 'center',
    color: '#6B7280'
  }}>
    <h1>{title}</h1>
    <p>Página en construcción...</p>
  </div>
);

export default App;
