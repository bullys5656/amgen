import { useState, useEffect } from 'react';
import api from '../../services/api';
import { getCurrentWeekInfo, formatDate } from '../../utils';
import './AuditoriaStock.css';

const CheckIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#28A745" strokeWidth="2.5">
    <polyline points="20,6 9,17 4,12" />
  </svg>
);

const XIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#DC3545" strokeWidth="2.5">
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

const isInCurrentWeek = (fechaUltimaCarga) => {
  if (!fechaUltimaCarga) return false;
  const { startDate, endDate } = getCurrentWeekInfo();
  const fecha = new Date(fechaUltimaCarga);
  return fecha >= startDate && fecha <= endDate;
};

const AuditoriaStock = () => {
  const [droguerias, setDroguerias] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.get('/droguerias')
      .then((res) => setDroguerias(res.data))
      .catch(() => setError('Error al cargar las droguerías'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="auditoria-loading">Cargando...</div>;
  }

  if (error) {
    return <div className="auditoria-error">{error}</div>;
  }

  return (
    <div className="auditoria-page">
      <div className="auditoria-table-wrapper">
        <table className="auditoria-table">
          <thead>
            <tr>
              <th className="auditoria-table__th auditoria-table__th--drogueria">Droguería</th>
              <th className="auditoria-table__th auditoria-table__th--fecha">Fecha Ultima Carga</th>
              <th className="auditoria-table__th auditoria-table__th--status"></th>
            </tr>
          </thead>
          <tbody>
            {droguerias.map((d) => {
              const enSemana = isInCurrentWeek(d.fechaUltimaCarga);
              return (
                <tr key={d.drogueriaId} className="auditoria-table__row">
                  <td className="auditoria-table__td">{d.nombre}</td>
                  <td className="auditoria-table__td">
                    {d.fechaUltimaCarga ? formatDate(d.fechaUltimaCarga) : '00/00/0000'}
                  </td>
                  <td className="auditoria-table__td auditoria-table__td--icon">
                    {enSemana ? <CheckIcon /> : <XIcon />}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AuditoriaStock;